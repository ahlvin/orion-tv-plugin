# Orion Screener → TradingView / Bitunix

Chrome/Edge/Brave extension. Adds two small buttons to the left of every
row on https://screener.orionterminal.com/:

- **TV** → opens that symbol's Binance USDT-M perpetual chart on TradingView
- **BX** → opens that symbol's contract-trade page on Bitunix

Both open in a new tab.

## Install (unpacked / dev mode — no store review needed)

1. Unzip this folder somewhere permanent (don't delete it after installing —
   Chrome loads the extension directly from these files).
2. Go to `chrome://extensions`
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select the `orion-tv-plugin` folder.
5. Open https://screener.orionterminal.com/ (hard refresh if it was already
   open: Ctrl+Shift+R) — the TV/BX buttons appear at the start of every row.

## How it works

- A content script watches the page's table (it re-renders constantly with
  live data, and is virtualized — rows get recycled as you scroll) and
  injects a new leftmost column with a chart-icon button.
- Each symbol cell in Orion is rendered as an icon + a hidden two-letter
  fallback + the real symbol text in a `<span>`. The extension reads that
  `<span>` directly (skipping the hidden fallback), so no more mangled
  tickers like "SOSOL" or "BIBIRB".
- Clicking a button re-reads that row's symbol **at the moment you click**
  (not when the button was first created) — this matters because Orion's
  table is virtualized and recycles row elements as you scroll, so anything
  cached at button-creation time can go stale.
- Opens (TV): `https://www.tradingview.com/chart/?symbol=BINANCE:<SYMBOL>USDT.P`
- Opens (BX): `https://www.bitunix.com/contract-trade/<SYMBOL>USDT`

## Adding more destinations / fixing a symbol mapping

Open `content.js` and look at the `DESTINATIONS` array near the top — each
entry is just a label + a function that turns the raw scraped symbol into a
URL. Add a new object to the array to open another site the same way, or
tweak `url()` on an existing entry if a particular symbol maps wrong.

## Files

- `manifest.json` — extension config (Manifest V3)
- `content.js` — table scanning, button injection, symbol extraction
- `style.css` — styling for the injected button/column
- `icon16.png` / `icon48.png` / `icon128.png` — extension icons
