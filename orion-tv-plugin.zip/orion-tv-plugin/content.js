(() => {
  'use strict';

  // ---- extracting the real symbol text -----------------------------------
  // Orion renders each symbol cell as:
  //   <div class="flex items-center gap-2">
  //     <img ...>                                  (coin logo, if it loads)
  //     <div style="display:none">ET</div>          (hidden fallback initials)
  //     <span class="... font-medium">ETHUSDT</span> (the real symbol)
  //   </div>
  // The fallback <div> is hidden with CSS but its text still shows up in
  // .textContent, which is what was gluing "ET" + "ETHUSDT" together into
  // "ETETHUSDT"-style garbage. The real symbol is reliably the LAST <span>
  // in the cell, so we grab that directly instead of the whole cell's text.
  function extractSymbolText(cell) {
    const spans = cell.querySelectorAll('span');
    if (spans.length) {
      return spans[spans.length - 1].textContent.trim();
    }
    return cell.textContent.trim();
  }

  function normalizeBase(raw) {
    let sym = raw.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    return sym.replace(/(USDT|USDC|BUSD|PERP|USD)$/, '');
  }

  // ---- destinations --------------------------------------------------------
  // Each destination: a short label (used for the button icon + tooltip) and
  // a function that turns a raw scraped symbol into a target URL. Add more
  // entries here to open other sites the same way.
  const DESTINATIONS = [
    {
      key: 'tv',
      label: 'TV',
      favicon: 'https://www.tradingview.com/favicon.ico',
      title: (sym) => `Open ${sym} on TradingView (Binance perp)`,
      url: (raw) => {
        const base = normalizeBase(raw);
        return `https://www.tradingview.com/chart/?symbol=${encodeURIComponent(`BINANCE:${base}USDT.P`)}`;
      },
    },
    {
      key: 'bx',
      label: 'BX',
      favicon: 'https://www.bitunix.com/favicon.ico',
      title: (sym) => `Open ${sym} on Bitunix`,
      url: (raw) => {
        const base = normalizeBase(raw);
        return `https://www.bitunix.com/contract-trade/${base}USDT`;
      },
    },
  ];

  // ---- table row injection ----------------------------------------------
  function getVisibleCells(row) {
    return Array.from(row.children).filter(
      (c) => !c.classList.contains('otv-btn-cell') && !c.classList.contains('otv-header-cell')
    );
  }

  function findSymbolColumnIndex(headerRow) {
    const cells = getVisibleCells(headerRow);
    for (let i = 0; i < cells.length; i++) {
      if (/symbol/i.test(cells[i].textContent)) return i;
    }
    return -1;
  }

  function makeButton(dest, row, symbolIdx) {
    const btn = document.createElement('button');
    btn.className = 'otv-btn';
    btn.type = 'button';

    const img = document.createElement('img');
    img.className = 'otv-btn-icon';
    img.src = dest.favicon;
    img.alt = dest.label;
    img.addEventListener('error', () => {
      img.remove();
      btn.textContent = dest.label;
    }, { once: true });
    btn.appendChild(img);

    // symbol is re-read live from the row at click time (not cached at
    // creation time) because Orion's table is virtualized and recycles row
    // DOM nodes as you scroll, so anything cached earlier can go stale.
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      const cells = getVisibleCells(row);
      const symbolCell = cells[symbolIdx];
      const symbolText = symbolCell ? extractSymbolText(symbolCell) : '';
      if (!symbolText) return;
      window.open(dest.url(symbolText), '_blank', 'noopener');
    });
    btn.title = dest.title('');
    return btn;
  }

  function processTable(table) {
    const headerRow = table.querySelector('thead tr') || table.querySelector('tr');
    if (!headerRow) return;

    const symbolIdx = findSymbolColumnIndex(headerRow);
    if (symbolIdx === -1) return;

    if (!headerRow.querySelector(':scope > .otv-header-cell')) {
      const th = document.createElement(headerRow.firstElementChild?.tagName || 'th');
      th.className = 'otv-header-cell';
      headerRow.insertBefore(th, headerRow.firstElementChild);
    }

    const bodyRows = table.querySelectorAll('tbody tr');
    bodyRows.forEach((row) => {
      if (row.querySelector(':scope > .otv-btn-cell')) return; // already has buttons
      const cells = getVisibleCells(row);
      if (!cells[symbolIdx]) return;

      const td = document.createElement('td');
      td.className = 'otv-btn-cell';
      DESTINATIONS.forEach((dest) => td.appendChild(makeButton(dest, row, symbolIdx)));
      row.insertBefore(td, row.firstElementChild);
    });
  }

  function scan() {
    document.querySelectorAll('table').forEach(processTable);
  }

  const observer = new MutationObserver(() => {
    clearTimeout(scan._t);
    scan._t = setTimeout(scan, 150);
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
  scan();
})();
